package com.hpharm.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hpharm.app.data.StockTransaction
import com.hpharm.app.data.TransactionType
import com.hpharm.app.ui.theme.DangerRed
import com.hpharm.app.ui.theme.PharmaAccent
import com.hpharm.app.ui.theme.PharmaGreen
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: ProductViewModel,
    onBack: () -> Unit
) {
    val products by viewModel.products.collectAsState()
    val transactions by viewModel.recentTransactions.collectAsState()

    val totalUnits = products.sumOf { it.quantity }
    val outOfStock = products.count { it.quantity == 0 }
    val expiringSoon = products.count { isExpiringSoon(it.expirationDate, Date()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tableau de bord", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    StatCard("Produits", "${products.size}", modifier = Modifier.weight(1f), color = PharmaGreen)
                    StatCard("Unités totales", "$totalUnits", modifier = Modifier.weight(1f), color = PharmaAccent)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    StatCard("Rupture de stock", "$outOfStock", modifier = Modifier.weight(1f), color = DangerRed)
                    StatCard("Expire bientôt", "$expiringSoon", modifier = Modifier.weight(1f), color = DangerRed)
                }
            }
            item {
                Text("Transactions récentes", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
            if (transactions.isEmpty()) {
                item { Text("Aucune transaction.", modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(transactions, key = { it.id }) { tx -> DashboardTransactionRow(tx) }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier, color: Color) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = color)
        }
    }
}

@Composable
fun DashboardTransactionRow(tx: StockTransaction) {
    val sdf = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE) }
    val isIn = tx.type == TransactionType.IN
    Card(shape = RoundedCornerShape(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(tx.productName, fontWeight = FontWeight.Bold)
                Text(sdf.format(Date(tx.date)), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                (if (isIn) "+" else "-") + tx.quantity,
                fontWeight = FontWeight.Black,
                color = if (isIn) PharmaGreen else DangerRed
            )
        }
    }
}

/**
 * A product is considered "expiring soon" if its MM/AA expiration date falls
 * within the next 60 days from [currentDate].
 */
fun isExpiringSoon(expirationDateStr: String, currentDate: Date): Boolean {
    if (expirationDateStr.isBlank()) return false
    return try {
        val parts = expirationDateStr.split("/")
        if (parts.size != 2) return false
        val month = parts[0].toInt()
        val year = 2000 + parts[1].toInt()

        val expiryCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val nowCal = Calendar.getInstance().apply { time = currentDate }
        val diffDays = (expiryCal.timeInMillis - nowCal.timeInMillis) / (1000 * 60 * 60 * 24)
        diffDays in 0..60
    } catch (e: Exception) {
        false
    }
}
