package com.hpharm.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.hpharm.app.data.StockTransaction
import com.hpharm.app.data.TransactionType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    productId: Int,
    viewModel: ProductViewModel,
    onBack: () -> Unit
) {
    val product by viewModel.getProduct(productId).collectAsState(initial = null)
    val transactions by viewModel.getTransactionsForProduct(productId).collectAsState(initial = emptyList())

    var showTransactionDialog by remember { mutableStateOf<TransactionType?>(null) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var transactionQty by remember { mutableStateOf("1") }

    val currentProduct = product

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(currentProduct?.name ?: "Détails") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Supprimer", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { padding ->
        if (currentProduct == null) {
            Box(modifier = Modifier.padding(padding).fillMaxSize())
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    if (currentProduct.imagePath != null) {
                        AsyncImage(
                            model = currentProduct.imagePath,
                            contentDescription = currentProduct.name,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            Icons.Default.Inventory2,
                            contentDescription = null,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }
            }

            item {
                DetailRow(Icons.Default.LocationOn, "Emplacement", currentProduct.location)
            }
            item {
                DetailRow(Icons.Default.Inventory2, "Quantité", "${currentProduct.quantity}")
            }
            if (currentProduct.expirationDate.isNotBlank()) {
                item { DetailRow(Icons.Default.CalendarMonth, "Expiration", currentProduct.expirationDate) }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { showTransactionDialog = TransactionType.IN },
                        modifier = Modifier.weight(1f)
                    ) { Text("Entrée") }
                    OutlinedButton(
                        onClick = { showTransactionDialog = TransactionType.OUT },
                        modifier = Modifier.weight(1f)
                    ) { Text("Sortie") }
                }
            }

            item {
                Text("Historique", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }

            if (transactions.isEmpty()) {
                item { Text("Aucune transaction.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(transactions, key = { it.id }) { tx -> TransactionRow(tx) }
            }
        }

        if (showTransactionDialog != null) {
            val type = showTransactionDialog!!
            AlertDialog(
                onDismissRequest = { showTransactionDialog = null },
                title = { Text(if (type == TransactionType.IN) "Entrée de stock" else "Sortie de stock") },
                text = {
                    OutlinedTextField(
                        value = transactionQty,
                        onValueChange = { if (it.all { c -> c.isDigit() }) transactionQty = it },
                        label = { Text("Quantité") }
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val qty = transactionQty.toIntOrNull() ?: 0
                        if (qty > 0) {
                            viewModel.recordTransaction(currentProduct, type, qty)
                        }
                        transactionQty = "1"
                        showTransactionDialog = null
                    }) { Text("Confirmer") }
                },
                dismissButton = {
                    TextButton(onClick = { showTransactionDialog = null }) { Text("Annuler") }
                }
            )
        }

        if (showDeleteDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteDialog = false },
                title = { Text("Supprimer") },
                text = { Text("Voulez-vous vraiment supprimer ce produit ?") },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.deleteProduct(currentProduct)
                        showDeleteDialog = false
                        onBack()
                    }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteDialog = false }) { Text("Annuler") }
                }
            )
        }
    }
}

@Composable
fun DetailRow(icon: ImageVector, label: String, value: String) {
    Card(shape = RoundedCornerShape(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Column {
                Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun TransactionRow(tx: StockTransaction) {
    val sdf = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE) }
    val isIn = tx.type == TransactionType.IN
    Card(shape = RoundedCornerShape(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(if (isIn) "Entrée" else "Sortie", fontWeight = FontWeight.Bold)
                Text(sdf.format(Date(tx.date)), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                (if (isIn) "+" else "-") + tx.quantity,
                fontWeight = FontWeight.Black,
                color = if (isIn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
    }
}
